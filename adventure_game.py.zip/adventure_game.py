import random
import time
import sys


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(2)


def male_character():
    print_pause("Your name is Francis Delorean""...")
    print_pause("Gender: Masculine")
    print_pause("Type: Young Adult/ Mixed Race")
    print_pause("Nationality: British")
    print_pause("Location: London, United Kingdom")
    print_pause("Language: English")
    print_pause("Age: 23")
    print_pause("Birth date: June 19, 1998 (12:03 AM)")
    print_pause("Height: 183 cm / 6 ft")
    print_pause("Weight: 75 kg / 165.347 lbs")
    print_pause("Handedness: Right")
    print_pause("Blood type: AB-\n")


def female_character():
    print_pause("Your name is Rosalina Azzuro""...")
    print_pause("Gender: Feminine")
    print_pause("Type: Young Adult/ Latino")
    print_pause("Nationality: American")
    print_pause("Location: San Diego, United States of America")
    print_pause("Language: English, Spanish")
    print_pause("Age: 21")
    print_pause("Birth date: May 2, 2000 (6:12 PM)")
    print_pause("Height: 163 cm / 5'4 ft")
    print_pause("Weight: 60 kg / 132.277 lbs")
    print_pause("Handedness: Right")
    print_pause("Blood type: O+\n")


def character_choice():
    gender = ['a Male', 'a Female']
    select = random.choice(gender)
    print("\nThe character you will be playing is:", select, "\n")
    if select == 'a Male':
        male_character()
        print_pause("You were in the estate with the mandem,"
                    " but your mom ask you to go the shops for her."
                    " Then suddenly something hit you and passed out.\n")
        print_pause("...\n")
    elif select == 'a Female':
        female_character()
        print_pause("You was enjoying a bike ride on"
                    " Coronado Beach and lost control."
                    " Then you hit your head...\n")
        print_pause("...\n")


def intro():
    print_pause("\n~~~~~SLOWLY OPENING YOUR EYES~~~~~\n")
    print_pause("\nYou woke up confused and do not know where you are.")
    print_pause("The first thing you did was to start to"
                " look for your phone to call your mom.")
    print_pause("But the phone has no network,"
                " you need to find better area to get some.")
    print_pause("You look around and you are in room,"
                " with grey high concrete walls, a reinforced door"
                " and large interrogation mirror.")
    print_pause("Then you realised you have been kidnapped and now,"
                " you have to figure what actually happened."
                "So check your pockets and everything is there.")
    print_pause("What will you do?\n")


def first_room(items):
    answer = input("1. Look for something sharp to break the mirror\n"
                   "2. Try to break the door\n")
    if answer == '1':
        print_pause("\nYou find a silver metal chair in the corner."
                    " You tried to launch it into the glass but failed..."
                    "Damn it's made out of plastic!\n")
        print_pause("The guard came in and hit your head!\n")
        print_pause("...\n")
        game_over(items)
    elif answer == '2':
        print_pause("\nYou sprinted into the door and you managed to"
                    " break it enough from the hinges..."
                    "Now, you are in a alleway!\n")
        print_pause("...\n")
    alleway(items)


def alleway(items):
    print_pause("Sweet! You find yourself in a dilemma.")
    print_pause("There is three paths and only one path will take your further"
                ". One on the left, in front and on your right")
    print_pause("There is some fresh breeze coming from one of the paths,"
                " which one will you take..?\n")
    answer = input("1. Take a Left\n"
                   "2. Go forward\n"
                   "3. Quickly follow the path on your right!\n")
    if answer == '1':
        print_pause("\nSomething hit you ...bang!")
        print_pause("Better luck next time!")
        print_pause("...\n")
        game_over(items)
    elif answer == '2':
        print_pause("\n...")
        print_pause("\nYou got lucky, a guard was on the left just"
                    " started his shift...SSHH!"
                    " Don't make any noise, they might hear you!")
        print_pause("You are at the end of the alleway and there is an exit,"
                    " but it has an alarm attached."
                    "You look around and there is a elevator\n"
                    "You quickly got in"
                    "before the guard do a security check!\n")
        elevator(items)
    else:
        print_pause("\nYou are at a dead end and the guard find you... "
                    "They take you back to the room.")
        game_over(items)


def elevator(items):
    print_pause("\n~~~~~QUIETLY RUNNING~~~~~\n")
    print_pause("Finally made it!"
                " The elevator doors closes and you find relief!"
                " Then suddenly you hear voice emitting saying:\n"
                "You are the one of the smartest in figuring out my games."
                " The next level will determine,"
                " If you are worth for your higher self..haha!\n")
    print_pause("...\n")
    print_pause("Damn! That was awkward....PFFT! Higher self."
                " You just realised there is only two floors..."
                "which one will you push?.")
    answer = input("1. Ground Floor\n"
                   "2. First Floor\n")
    if answer == '1':
        print_pause("\n...\n")
        print_pause("\nYou have selected the ground floor.")
        print_pause("Nice elevator music!")
        print_pause("The lift finally stops and the bell rang...\n"
                    "The door slowly opens half way.\n"
                    " You see something strange..\n"
                    " You see zombies running towards you"
                    " and the door opens.\n"
                    " The zombies storms in and you faced death..")
        game_over(items)
    elif answer == '2':
        print_pause("\n...\n")
        print_pause("\nThe voice from the speaker is talking to you!"
                    " Fortunately, you got saved from a horrible judgment."
                    "\nBe thankful for your concussion!")
        print_pause("You have reached the first floor\n"
                    "You have been greeted by scientists and mercenaries."
                    "They injected you with something and tell you:")
        print_pause("Consider yourself lucky, life starts now!")
        print_pause("You have won! You have been put into a group"
                    " to be transportated into a safe zone!\n")
        game_over(items)


def game_over(items):
    print_pause("GAME OVER\n")
    print_pause("Would you like to play again?\n")
    answer = input("YES\n"
                   "NO\n")

    if answer == 'YES':
        print_pause("\nVery good! Never give up\n")
        print_pause("We will put you into a time machine and"
                    " go back to play again from the start!\n")
        print_pause("\n...")
        print_pause("\nrebooting...")
        print_pause("...3")
        print_pause("..2")
        print_pause(".1\n")
        character_choice()
    elif answer == 'NO':
        print_pause("\n...\n")
        print_pause("See you again!\n")
        sys.exit("Thanks for playing!\n")


def play_game():
    items = []
    character_choice()
    intro()
    first_room(items)
    alleway(items)
    elevator(items)
    game_over(items)


play_game()
