// Submit button 
const makeConvas = () => {
  const rows = document.getElementById('inputHeight').value;
  const columns = document.getElementById('inputWidth').value;
  const table = document.getElementById('tbody');
  var tbody = '';

  // Generating Table according to inputs 
  for (var i = 0; i < rows; i++) {
    tbody += '<tr>';
    for (var j = 0; j < columns; j++) {
      tbody += '<td onclick="fillSquare(this)">';
      tbody += '</td>'
    }
    tbody += '</tr>';
  }
  table.innerHTML = tbody;
}

// Fill Color on click 
const fillSquare = (e) => {
  const color = document.getElementById('colorPicker').value
  e.setAttribute('style', `background-color: ${color}`)
}